# WAVE BANK
===========
A Prototype Bank App that runs on CLI or Computer terminal. Written with Python and SQlite3 for Database


### INSTRUCTION
===============

- Install sqlite3 app on your computer.

- Ensure "waveBankAccountProject" folder is saved any where on your computer. If not, this application will not work.

- Run the "waveBankAccount.py" file in your terminal.

- Enjoy your experience with our Bank.

- Thank you very much !!!.